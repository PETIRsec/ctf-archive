Your files have been Encrypted!
Send an Email to rescue them: supportdoc@protonmail.ch
Your id is 12e8f0dd-8196-449c-a26f-7a6cadab126a