const { chromium, firefox, webkit } = require('playwright');
const JWTHelper = require('./jwt/JWTHelper')
const fs = require('fs');

const browser_options = {
    headless: true,
    args: [
        '--disable-dev-shm-usage',
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-gpu',
        '--no-gpu',
        '--disable-default-apps',
        '--disable-translate',
        '--disable-device-discovery-notifications',
        '--disable-software-rasterizer',
        '--disable-xss-auditor'
    ],
    ignoreHTTPSErrors: true
};
let token = JWTHelper.sign({ role:"admin",id: 1, balance: 0});
const cookies = [{
    'name': 'jwt',
    'value': token
}];
function sleep(s) {
    return new Promise((resolve) => setTimeout(resolve, s));
}

async function viewComplaint(complain){
	let context = null;
	let initBrowser = await firefox.launch(browser_options)
	context = await initBrowser.newContext();
	 try {
		const page = await context.newPage();
		await context.addCookies([{
			name: "jwt",
			httpOnly: false,
			value: token,
			url: 'http://127.0.0.1:3314'
		}]);
		await page.goto(`http://127.0.0.1:3314/check?complain=${complain}`, {
			waitUntil: 'load',
			timeout: 10 * 1000
		});
		await sleep(15000);
		return true;
	} catch (e) {
		console.error(e);
		return false;
	} finally {
		await context.close();
	}
};

module.exports = { viewComplaint };