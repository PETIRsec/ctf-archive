const sqlite = require('sqlite-async');
const crypto = require('crypto')
const { v4 } = require('uuidv4');

class Database {
	constructor(db_file) {
		this.db_file = db_file;
		this.db = undefined;
	}
	
	async connect() {
		this.db = await sqlite.open(this.db_file);
	}

	async migrate() {
		return this.db.exec(`
            DROP TABLE IF EXISTS users;

            CREATE TABLE IF NOT EXISTS users (
                id         UUID NOT NULL PRIMARY KEY,
                email   VARCHAR(255) NOT NULL UNIQUE,
                password   VARCHAR(255) NOT NULL,
				balance INTEGER DEFAULT 400,
				token VARCHAR(255),
				claimed INTEGER DEFAULT 0
            );
			`);
	}

	async registerUser(user, pass) {
		return new Promise(async (resolve, reject) => {
			try {
				let randuuid = crypto.randomUUID()
				let query = await this.db.prepare('INSERT INTO users (id,email, password) VALUES (?,?,?)');
				resolve((await query.run(randuuid,user.toString(), pass)));
			} catch(e) {
				reject(e);
			}
		});
	}

	async claimReward(userId){
		return new Promise(async (resolve, reject) => {
			try {
				let query = await this.db.prepare('UPDATE users SET balance = balance + 100 WHERE id = ?');
				resolve(await query.run(userId));
			} catch(e) {
				reject(e);
			}
		});
	}
	async setClaimed(userId){
		return new Promise(async (resolve, reject) => {
			try {
				let query = await this.db.prepare('UPDATE users SET claimed = 1 WHERE id = ?');
				resolve(await query.run(userId));
			} catch(e) {
				reject(e);
			}
		});
	}
	async loginUser(user, pass) {
		return new Promise(async (resolve, reject) => {
			try {
				let query = await this.db.prepare('SELECT * FROM users WHERE email = ? and password = ?');
				resolve(await query.get(user, pass));
			} catch(e) {
				reject(e);
			}
		});
	}

	async getUser(user) {
		return new Promise(async (resolve, reject) => {
			try {
				let query = await this.db.prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
				resolve(await query.get(user));
			} catch(e) {
				reject(e);
			}
		});
	}

	async checkUser(user) {
		return new Promise(async (resolve, reject) => {
			try {
				let query = await this.db.prepare('SELECT email FROM users WHERE email = ?');
				let row = await query.get(user);
				resolve(row !== undefined);
			} catch(e) {
				reject(e);
			}
		});
	}
	async generateReward(userId){
		return new Promise(async (resolve, reject) => {
			try {
				const key = "6T2Uz2IAkpFLscDpoWA7YWfb4R"+ (Math.floor(new Date().getTime()/100)).toString()
				const hash = crypto.createHash('sha256').update(key).digest('hex');
				let query = await this.db.prepare('UPDATE users SET token = ? WHERE id = ?');
				await query.run(hash,userId)
				resolve(hash);
			} catch(e) {
				reject(e);
			}
		});
	}
}

module.exports = Database;