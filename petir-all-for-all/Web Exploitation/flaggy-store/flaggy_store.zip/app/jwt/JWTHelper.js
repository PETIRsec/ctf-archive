const jwt = require('jsonwebtoken');

const APP_SECRET = process.env.APPSECRET;

module.exports = {
	sign(data) {
		data = Object.assign(data);
		console.log(APP_SECRET)
		return (jwt.sign(data, APP_SECRET, { algorithm:'HS256'}))
	},
	decode(token) {
		return (jwt.verify(token, APP_SECRET, { algorithm:'HS256' }));
	}
}