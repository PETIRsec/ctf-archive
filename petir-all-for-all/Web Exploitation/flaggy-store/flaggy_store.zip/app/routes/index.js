const bot            = require('../bot');
const express        = require('express');
const router         = express.Router();
const JWTHelper      = require('../jwt/JWTHelper');
const AuthMiddleware = require('../middleware/AuthMiddleware');
const { validationResult, check } = require('express-validator')

let db;

const response = data => ({ message: data });

router.get('/', (req, res) => {
	return res.render('index.html');
});

router.get('/home', AuthMiddleware, async(req,res)=>{
	return db.getUser(req.data.id)
		.then(user => {
			if(user === undefined) return res.redirect('/');
			res.render('home.html', { user });
		})
	.catch(() => res.status(500).send(response('Something went wrong!')));
})

router.post('/api/login', check('email').isEmail(),async (req, res) => {
	const { email, password } = req.body;
	const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).send(response("Invalid Email or Password"));
    }
	if (email && password) {
		return db.loginUser(email, password)
			.then(user => {
				let token = JWTHelper.sign({ id: user.id, role:"guest",email: user.email, balance: user.balance});
				res.cookie('jwt', token, { maxAge: 2000000000000000 });
				return res.send(response('User authenticated successfully!'));
			})
			.catch(() => res.status(403).send(response('Invalid Email or Password!')));
	}
	return res.status(500).send(response('Missing parameters!'));
});

router.post('/api/register', check('email').isEmail(), async (req, res) => {
	const { email, password } = req.body;
	const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).send(response("Invalid Email or Password"));
    }
	if (email && password) {
		return db.checkUser(email)
			.then(user => {
				if (user) return res.status(401).send(response('User already registered!'));
				return db.registerUser(email, password)
					.then(()  => res.send(response('User registered successfully!')))
			})
			.catch((err) => {
				res.send(response('Something went wrong!'))
		});
	}
	return res.status(401).send(response('Please fill out all the required fields!'));
});

router.get('/check',AuthMiddleware, async (req, res) => {
	if(req.ip != '127.0.0.1') return res.send(response("Not Authorized"))
	let complain = req.query.complain
	res.render('check.html',{complain});
});

router.post('/api/sendcomplain', AuthMiddleware, async (req, res) => {
	const { content } = req.body;
	if(content){
		bot.viewComplaint(content);
		return res.send(response('Your complain is checked by admin'));
	}
	else{
		return res.status(403).send(response('Empty content cannot be checked'));
	}
})

router.post('/api/realflag',AuthMiddleware, async (req, res) => {
	return db.getUser(req.data.id)
		.then(user => {
			if(user === undefined) return res.redirect('/');
			if(user.balance >= 700){
				let rflag= process.env.RFLAG
				return res.json({message: rflag})
			}
			return res.status(500).json({message: "Too bad, you don't have enough money"})
		})
	.catch(() => res.status(403).send(response('Something Went Wrong')));
});
router.get('/api/generate', AuthMiddleware, async(req,res)=>{
	if(req.ip !== '127.0.0.1') return res.redirect('/');
	return db.getUser(req.data.id).then(
		user =>{
			if (user === undefined) return res.send(response('Token is Invalid'));
			if(user.token !== null){
				return res.send(response('Token have been generated for your account'))
			}
			return db.generateReward(req.data.id).then((token)=>{
				return res.send(response(`Token generated for account ${req.data.id} value:${token}`))
			}).catch(()=>{res.status(500).json({ error: 'Generate Failed' });})
		})
		.catch(()=>{res.status(500).json({ error: 'Generate Failed' });})
})
router.get('/api/claim', AuthMiddleware, async(req,res)=>{
	return db.getUser(req.data.id).then(
		user =>{
			if (user === undefined) return res.redirect('/');
			if(user.token === req.query.token && user.claimed === 0){
				return db.claimReward(req.data.id).then(()=>{
					return db.setClaimed(req.data.id).then(()=>{
						return res.send(response(`Reward Claimed ${req.data.id}`))
					}).catch(()=>{res.status(500).json({ error: 'Something went wrong' });})
				}).catch(()=>{res.status(500).json({ error: 'Something went wrong' });})
			}
			return res.status(500).json({message: "You have claimed your reward"})
		})
})
router.post('/api/miniflag',AuthMiddleware, async (req, res) => {
	return db.getUser(req.data.id)
	.then(user => {
		if(user === undefined) return res.redirect('/');
		if(user.balance >= 400){
			let fflag= process.env.FFLAG
			console.log(fflag)
			return res.json({message: fflag})
		}
		return res.status(500).json({message: "Too bad, you don't have enough money"})
	})
.catch(() => res.status(403).send(response('Something Went Wrong')));
});

router.get('/logout', (req, res) => {
	res.clearCookie('jwt');
	return res.redirect('/');
});

module.exports = database => { 
	db = database;
	return router;
};
