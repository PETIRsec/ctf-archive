document.addEventListener('DOMContentLoaded', () => {
    const realFlagButton = document.getElementById('real-flag-btn');
    const miniFlagButton = document.getElementById('mini-flag-btn');
    const complaintButton = document.getElementById('complain-btn');
    const complaintText = document.getElementById('complaint-text');

    realFlagButton.addEventListener('click', () => {
        fetch('/api/realflag', {
            method: 'POST',
            credentials: 'include', 
        })
        .then(response => response.json())
        .then(data => {
            if (data.message) {
                alert(data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while processing your request.');
        });
    });

    miniFlagButton.addEventListener('click', () => {
        fetch('/api/miniflag', {
            method: 'POST',
            credentials: 'include', 
        })
        .then(response => response.json())
        .then(data => {
            if (data.message) {
                alert(data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while processing your request.');
        });
    });

    complaintButton.addEventListener('click', () => {
        const complaintContent = complaintText.value.trim();
        if (complaintContent) {
            fetch('/api/sendcomplain', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ content: complaintContent }),
                credentials: 'include', 
            })
            .then(response => response.json())
            .then(data => {
                if (data.message) {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while sending your complaint.');
            });
        } else {
            alert('Please enter a complaint before submitting.');
        }
    });
});
