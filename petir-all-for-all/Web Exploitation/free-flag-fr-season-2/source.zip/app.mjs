import express from 'express';
import sqlite3 from 'sqlite3';
import bcrypt from 'bcrypt';
import path from 'path';
import { fileURLToPath } from 'url';
import cookieParser from 'cookie-parser';
import crypto from 'crypto';
import { body, validationResult } from 'express-validator';
import xss from 'xss';
import fs from 'fs';

const app = express();
const port = 3000;
const hostname = '0.0.0.0';
const db = new sqlite3.Database('./js.db');
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const sessions = new Map();

db.serialize(() => {
    db.run("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password TEXT, isAdmin INTEGER)");
});

function sanitizeInput(input) {
    return xss(input);
}

function verifyToken(req, res, next) {
    const { sessionId } = req.cookies;
    const sessionData = sessions.get(sessionId);
    if (!sessionData) {
        return res.status(401).json({ success: false, message: 'Unauthorized: Invalid session' });
    }
    req.user = sessionData;
    next();
}

function csrfProtection(req, res, next) {
    const token = req.headers['x-csrf-token'];
    if (!token || token !== req.cookies.csrfToken) {
        return res.status(403).json({ success: false, message: 'Invalid CSRF token' });
    }
    next();
}

function merge(target, source) {
    for (let key in source) {
        if (typeof source[key] === 'object' && source[key] !== null) {
            if (!target[key]) target[key] = {};
            merge(target[key], source[key]);
        } else {
            target[key] = source[key];
        }
    }
    return target;
}

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

app.listen(port, hostname, () => {
    console.log(`Server is running on http://${hostname}:${port}`);
});

app.get('/', (req, res) => {
    res.redirect('/login');
});

app.get('/login', (req, res) => {
    const csrfToken = crypto.randomBytes(64).toString('hex');
    res.cookie('csrfToken', csrfToken, { httpOnly: true, sameSite: 'strict' });
    res.sendFile(path.join(__dirname, 'js_templates', 'login.html'));
});


app.post('/login', [
    body('username')
        .trim()
        .escape(),
    body('password')
], (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        const errorMessages = errors.array().map(error => error.msg);
        return res.status(400).json({ success: false, message: errorMessages });
    }

    const { username, password } = req.body;
    db.get("SELECT * FROM users WHERE username = ?", [username], (err, user) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Internal server error' });
        }
        if (user && bcrypt.compareSync(password, user.password)) {
            const sessionId = crypto.randomBytes(64).toString('hex');
            sessions.set(sessionId, { username: user.username });
            res.cookie('sessionId', sessionId, { httpOnly: true });
            res.json({ success: true, message: 'Logged in successfully', username: user.username });
        } else {
            res.status(401).json({ success: false, message: 'Invalid credentials' });
        }
    });
});


app.get('/register', (req, res) => {
    const csrfToken = crypto.randomBytes(64).toString('hex');
    res.cookie('csrfToken', csrfToken, { httpOnly: true, sameSite: 'strict' });
    res.sendFile(path.join(__dirname, 'js_templates', 'register.html'));  
});

app.post('/register', [
    body('username')
        .trim()
        .escape()
        .isLength({ min: 3, max: 20 })
        .withMessage('Username must be between 3 and 20 characters'),
    body('password')
        .isLength({ min: 5, max: 20 })
        .withMessage('Password must be between 5 and 20 characters')
], (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        const errorMessages = errors.array().map(error => error.msg);
        return res.status(400).json({ success: false, message: errorMessages });
    }

    const username = sanitizeInput(req.body.username);
    const password = req.body.password;

    if (username.toLowerCase() === 'admin' || username.toLowerCase() === 'administrator') {
        return res.status(400).json({ success: false, message: 'Username is not allowed' });
    }

    const hashedPassword = bcrypt.hashSync(password, 10);

    db.run("INSERT INTO users (username, password, isAdmin) VALUES (?, ?, ?)", [username, hashedPassword, 0], (err) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Internal server error' });
        }
        res.json({ success: true, message: 'User registered successfully' });
    });
});

app.get('/admin', verifyToken, (req, res) => {
    if (req.user.isAdmin) {
        return res.sendFile('flag.txt', { root: __dirname });
    } else {
        return res.status(403).send('Access denied!');
    }
});

app.get('/settings', verifyToken, (req, res) => {
    const csrfToken = crypto.randomBytes(64).toString('hex');
    res.cookie('csrfToken', csrfToken, { httpOnly: true, sameSite: 'strict' });
    let html = fs.readFileSync(path.join(__dirname, 'js_templates', 'settings.html'), 'utf8');
    html = html.replace('</head>', `<meta name="csrf-token" content="${csrfToken}"></head>`);
    html = html.replace('value=""', `value="${req.user.username}"`);
    res.send(html);
});

app.post('/settings', [
    verifyToken,
    csrfProtection,
    body('newPassword')
        .isLength({ min: 5, max: 20 })
        .withMessage('Password must be between 5 and 20 characters')
        .optional()
], (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        const errorMessages = errors.array().map(error => error.msg);
        return res.status(400).json({ success: false, message: errorMessages });
    }

    const sessionData = req.user;
    const updatedSettings = merge({}, req.body);

    if (sessionData.username === updatedSettings.username) {
        if (updatedSettings.newPassword) {
        const hashedPassword = bcrypt.hashSync(updatedSettings.newPassword, 10);
        db.run("UPDATE users SET password = ? WHERE username = ?", [hashedPassword, sessionData.username], (err) => {
            if (err) {
            return res.status(500).json({ success: false, message: 'Internal server error' });
            }
            return res.json({ success: true, message: 'Password updated successfully' });
        });
        } else {
        return res.json({ success: false, message: 'No password update requested' });
        }
    } else {
        return res.status(401).json({ success: false, message: 'Unauthorized Action' });
    }
});