const sqlite3 = require('sqlite3');
const {
    open
} = require('sqlite');
const fs = require('fs');
const flag = fs.readFileSync('./flag.txt', 'utf8');

class Database {
    constructor(db_file) {
        this.db_file = db_file;
        this.db = undefined;
    }

    async connect() {
        this.db = await open({
            filename: this.db_file,
            driver: sqlite3.Database
        });
    }

    async migrate() {
        await this.db.exec(`
            DROP TABLE IF EXISTS flag;
            CREATE TABLE IF NOT EXISTS flag (
                flag   TEXT NOT NULL
            );

            INSERT INTO flag (flag) VALUES ('${flag}');

            DROP TABLE IF EXISTS protege;
            CREATE TABLE IF NOT EXISTS protege (
                id         INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                username   TEXT NOT NULL UNIQUE,
                stream     TEXT DEFAULT 'Web Exploitation',
                point      REAL DEFAULT 100
            );

            INSERT INTO protege (id, username, stream, point) VALUES
                (1, 'aseng', 'Reverse Engineering', 999999.99),
                (2, 'chronopad', 'Web Exploitation', 1050.23),
                (3, '0xre', 'Web Exploitation', 789.56),
                (4, 'bepe23', 'Web Exploitation', 921.12),
                (5, 'micel140', 'Web Exploitation', 1113.45),
                (6, 'boedegoat', 'Web Exploitation', 846.34),
                (7, 'ringoshiro', 'Reverse Engineering', 1302.78),
                (8, 'hasfin', 'Reverse Engineering', 657.89),
                (9, 'linglungtzy', 'Web Exploitation', 932.17),
                (10, 'Chumonsuke', 'Reverse Engineering', 1250.64),
                (11, 'meister420x69', 'Web Exploitation', 990.11),
                (12, 'robingoodfellow', 'Web Exploitation', 1204.23),
                (13, 'yobel', 'Web Exploitation', 1103.45),
                (14, 'minzelo', 'Reverse Engineering', 1380.55),
                (15, 'scaramochi', 'Reverse Engineering', 745.90),
                (16, 'tanknight', 'Reverse Engineering', 1334.77),
                (17, 'Hazy', 'Web Exploitation', 1178.22),
                (18, 'cheesecake', 'Reverse Engineering', 688.30),
                (19, 'eyetologist', 'Reverse Engineering', 1010.75),
                (20, 'firdaa_', 'Web Exploitation', 854.45),
                (21, 'Xovert', 'Binary Exploitation', 1117.38),
                (22, 'Hyoka', 'Reverse Engineering', 964.12),
                (23, 'Lyo', 'Reverse Engineering', 1248.79),
                (24, 'Ryuukami', 'Web Exploitation', 1023.45),
                (25, 'thecoolagentci', 'Reverse Engineering', 782.91),
                (26, 'liqued_', 'Web Exploitation', 1389.65),
                (27, 'Shiroz', 'Web Exploitation', 911.55),
                (28, 'routernobe', 'Web Exploitation', 733.40);
        `);
    }

    async getAllUser() {
        return this.db.all('SELECT * FROM protege');
    }

    async updatePoints(userId, credits) {
        await this.db.run('UPDATE protege SET point = ? WHERE id = ?', [credits, userId]);
    }

    async checkEligible(userId) {
        const row = await this.db.get('SELECT point FROM protege WHERE id = ' + userId);
        return row && row.point > 1337;
    }
}

module.exports = Database;