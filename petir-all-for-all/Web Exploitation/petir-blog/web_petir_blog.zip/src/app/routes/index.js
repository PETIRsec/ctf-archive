const express = require('express');
const router = express.Router({
    caseSensitive: true
});
const AuthMiddleware = require('../middleware/AuthMiddleware');
const routeCache = require('route-cache');
const bot = require('../bot');

let db;
let botVisiting = false;

const response = data => ({
    message: data
});

const cacheKey = (req, res) => {
    return `_${req.url}_${(req.headers['x-forwarded-for'] || req.ip)}`;
}

router.get('/', routeCache.cacheSeconds(30, cacheKey), (req, res) => {
    return res.render('index.html', req.headers);
});

router.get('/report', (req, res) => {
    return res.render('report.html', req.headers);
});


router.get('/admin', AuthMiddleware, (req, res) => {
    return res.render('admin.html', req.headers);
});


router.get('/api/users', AuthMiddleware, async (req, res) => {
    try {
        const users = await db.getAllUser();
        res.json(users);
    } catch (err) {
        res.status(500).json({
            message: 'Failed to retrieve users'
        });
    }
});

router.post('/api/modifyScore/:userId', AuthMiddleware, async (req, res) => {
    const userId = parseInt(req.params.userId, 10);
    const {
        newScore
    } = req.body;
    try {
        await db.updatePoints(userId, newScore);
        res.json({
            message: 'Score updated successfully'
        });
    } catch (err) {
        res.status(500).json({
            message: 'Failed to update score'
        });
    }
});

router.get('/api/checkEligibility/:userId', AuthMiddleware, async (req, res) => {
    const userId = req.params.userId;
    try {
        const eligible = await db.checkEligible(userId);
        res.json({
            eligible
        });
    } catch (err) {
        res.status(500).json({
            message: 'Failed to check eligibility'
        });
    }
});


router.post('/api/report', async (req, res) => {
    const {
        section
    } = req.body;
    if (botVisiting) return res.status(403).send(response('Please wait for the previous report to process first!'));
    if (section) {
        botVisiting = true;
        return bot.visitPost(section)
            .then(() => {
                botVisiting = false;
                return res.send(response('Report received successfully!'));
            })
            .catch(e => {
                botVisiting = false;
                return res.status(403).send(response('Something went wrong, please try again!'));
            })
    }
    return res.status(500).send(response('Missing required parameters!'));
});

router.get('/logout', (req, res) => {
    res.clearCookie('session');
    return res.redirect('/');
});

module.exports = database => {
    db = database;
    return router;
};