const userTable = document.getElementById('userTable');

fetch("/api/users")
    .then(response => response.json())
    .then(data => {

        data.forEach(user => {
            const row = document.createElement('tr');

            row.innerHTML = `
                <td>${user.id}</td>
                <td>${user.username}</td>
                <td><input type="number" value="${user.point}" id="score-${user.id}" class="form-control"></td>
                <td><button class="btn btn-primary" onclick="modifyScore(${user.id})">Modify</button></td>
                <td><button class="btn btn-secondary" onclick="checkEligibility(${user.id})">Check</button></td>
            `;

            userTable.appendChild(row);
        });

    })



function modifyScore(userid) {
    const newScore = document.getElementById(`score-${userid}`).value;
    fetch(`/api/modifyScore/${userid}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                newScore
            })
        })
        .then(response => response.json())
        .then(data => {
            alert(data.message);
        });
}

function checkEligibility(userid) {
    fetch(`/api/checkEligibility/${userid}`)
        .then(response => response.json())
        .then(data => {
            alert(`User is ${data.eligible ? 'eligible' : 'not eligible'} for joining PETIR Team.`);
        });
}