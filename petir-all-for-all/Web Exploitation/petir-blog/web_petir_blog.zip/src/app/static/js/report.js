document.getElementById('reportForm').addEventListener('submit', async function(event) {
    event.preventDefault();

    const section = document.getElementById('section').value;
    const feedback = document.getElementById('feedback').value;

    const responseMessage = document.getElementById('responseMessage');
    responseMessage.textContent = '';

    try {
        const response = await fetch('/api/report', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                section,
                feedback
            })
        });

        const result = await response.json();
        responseMessage.textContent = result.message;
        responseMessage.style.color = response.ok ? 'green' : 'red';
    } catch (error) {
        responseMessage.textContent = 'Error submitting report. Please try again.';
        responseMessage.style.color = 'red';
    }
});