#!/bin/bash

docker rm -f web_petir_blog

docker build -t web_petir_blog .
docker run -d --name web_petir_blog --network=MONGO-shopey -p 31337:31337 web_petir_blog
